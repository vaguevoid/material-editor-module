# Material Editor

* Run platform_native.exe

* Two windows should open - a window with a sprite, and an Egui window with ui controls.